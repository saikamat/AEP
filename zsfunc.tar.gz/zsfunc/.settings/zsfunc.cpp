#include <hls_stream.h>
#include <ap_axi_sdata.h>

void zsfunc(unsigned char p0,unsigned char p1,unsigned char p2,unsigned char p3,unsigned char p4,unsigned char p5,unsigned char p6,unsigned char p7,unsigned char p8,unsigned char iter) {

#pragma HLS INTERFACE s_axilite port=iter bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p1 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p2 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p3 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p4 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p5 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p6 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p7 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=p8 bundle=CRTL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL_BUS


unsigned char  m1;
unsigned char  m2;
unsigned char x,y;
//intSdCh opresult;

// I am taking input here
/*
 * p2]=P9;
 * p1]=P2;
 * p2]=P3;
 * p3]=P8;
 * p4]=P1;
 * p5]=P4;
 * p6]=P7;
 * p7]=P6;
 * p8]=P5;
 */

p0= p0 ? 1 :0;
p1= p1 ? 1 :0;
p2= p2 ? 1 :0;
p3= p3 ? 1 :0;
p4= p4 ? 1 :0;
p5= p5 ? 1 :0;
p6= p6 ? 1 :0;
p7= p7 ? 1 :0;
p8= p8 ? 1 :0;

// Configure the opresult variable
//opresult.keep =p0].keep;
//opresult.strb =p0].strb;
//opresult.user =p0].user;
//opresult.last =p0].last;
//opresult.id =  p0].id;
//opresult.dest =p0].dest;

//Do calculations
unsigned char  A=(!p1 && p2) + (!p2 && p5) +(!p5 && p8) + (!p8 && p7) + (!p7 && p6) + (!p6 && p3) + (!p3 && p0) + (!p0 && p1);
unsigned char  B=p1+p2+p5+p8+p7+p6+p3+p0;

m1= p1*p5*p7;
m2=p5*p7*p3;
x=(A == 1 && (B >= 2 && B <= 6) && !m1 && !m2);


m1=p1*p5*p3;
m2=p1*p7*p3;
y=(A == 1 && (B >= 2 && B <= 6) && !m1 && !m2);

//opresult.data=(x || y);
//outStream.write(opresult);
iter= (x || y);
//return (x||y);


}
